# Contact Form with SVG animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/joanasesinando/pen/gOrrNMj](https://codepen.io/joanasesinando/pen/gOrrNMj).

